# Web Squirrel
Chrome extension to save and manage your open tabs with one click

## Screenshots
<p align="center">
 <img src="screenshots/WS_ADD.png" width="320" height="300" />.                    <img src="screenshots/WS_OPEN.png" width="366" height="300" />
 </p>
 
